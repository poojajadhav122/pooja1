<?php
	require_once 'db_helper.php';
	final class db_project extends db_helper
	{
		function show_record()
		{
			//echo "hello";
			//select id,fname,lname from dbrecords where 1;
			//select columns name from table name where condition

			return $this->select("*","dbrecords","1");
		}
		
		function add_record($usfname,$uslname)
		{
			return parent::insert("dbrecords","fname,lname","'$usfname','$uslname'");
		}

		function edit_record($usfname,$uslname)
		{
			//update users set us_password='$newpass' where us_email='$email
			return db_helper::update("dbrecords","fname='$usfname'","lname='$uslname'");
		}
	}

	$obj = new db_project();

?>