<?php 

	require_once '../models/db_project.php';

	//pre($_POST);
		echo "<pre>";
		print_r($_POST);
		echo "</pre>";
	// if(empty($_POST['fname']))
	// {
	//   echo "First Name Can Not Be Blank";
 //    }
	// else if(!preg_match("/^[A-Za-z][A-Za-z ]+[A-Za-z]$/", $_POST['fname']))
	// {
	// 	echo "First Name Should Contain Alphabate";
	// }
	// else if(empty($_POST['lname']))
	// {
	//   echo "Last Name Can Not Be Blank";
 //    }
	// else if(!preg_match("/^[A-Za-z][A-Za-z ]+[A-Za-z]$/", $_POST['lname']))
	// {
	// 	echo "First Name Should Contain Alphabate";
	// }
	// else
	// {
	// 	//echo "ok";
	// 	$usfname=$_POST['fname'];
	// 	$uslname=$_POST['lname'];

	// 	if($obj->add_record($usfname,$uslname))
	// 	{
	// 			echo "Record Added Succesully";
	// 	}	
	// }
	

?>