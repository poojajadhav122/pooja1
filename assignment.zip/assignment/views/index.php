<!-- <?php
  // require_once "../models/db_project.php";
?> -->
<link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="../assets//css/style.css"/>
  
<div class="container">
  <form id="form-record">
    <div class="form-group">
      <label>First Name</label>
        <input type="text" class="form-control" id="fname" placeholder="Your First Name">
    </div>
    <div class="form-group">
      <label>Last Name</label>
        <input type="text" class="form-control" id="lname" placeholder="Your Last Name">
    </div>
    <button type="button" class="btn btn-default btn-add">ADD</button>
  </form>
  <hr>
  <!-- <div class="msg_add"></div> -->
  <a href="show_records.php">SHOW RECORDS</a>
</div>

<script src="../assets/js/jquery-3.3.1.min.js"></script>
<script src="../assets/js/jquery.js"></script>
<!-- <script src="../assets/js/main.js"></script> -->

<script src="../assets/js/assignment_project.js"></script>
  