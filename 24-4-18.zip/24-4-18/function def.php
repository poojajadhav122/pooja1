<?php 
  calculate(100,200,400); # this is called as the call function

   function calculate($a,$b,$c){ # this is called at the define function
   	echo $a+$b+$c;
   }

?>