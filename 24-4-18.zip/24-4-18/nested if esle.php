<?php
  $data=50;

  if ($data <10) {
  	echo "single digit:";
  }
  elseif ($data <100) {
  	echo "two digit no:";

  }
  else {
  	echo "multi digit no:";
  }


?>