<?php
for($i=0;$i<3;$i++){
	echo $i;
	$data[$i] = 100;
}
print_r($data);
?>