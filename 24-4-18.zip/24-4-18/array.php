<?php
$data=[100,200,240];

#echo $data;# echo dose not print complex stucture of array
print_r($data);
print_r($data[0]);#this do both complex struture and single no
echo $data[0];#echo print only single value of array
?>