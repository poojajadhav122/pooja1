<?php
   $no = 9867291457;

   $pattern ="/^[1-9][0-9]{9}$/";

   $res = preg_match($pattern, $no);
   echo $res;
?>