<?php
 abstract class tv{  //in abstract class we cannot create oject but we inherit theclass.

  }
 final class sonytv extends tv{ // in final class we cannot inherit but we can create object

  }
  // class xyztv extends sonytv{

//}  
  $remote = new sonytv();
  print_r($remote);

?>