<?php
   $no = "Pooja Jadhav";

   $pattern ="/^[a-zA-Z][a-zA-Z ]{1,}[a-zA-Z]$/";

   $res = preg_match($pattern, $no);
   echo $res;
?>