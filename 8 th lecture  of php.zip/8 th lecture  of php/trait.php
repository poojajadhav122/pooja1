<?php
 trait pdf{ //we use trait to avoid multileve inhertiance
 	function showpdf(){
 		echo "show";
 	}
 }
  // $objtpdf = new pdf(); // in trait we cannot create object
trait excel{
 	function showexcel(){
 		echo "show excel";
 	}
 }
 trait sms{}
 trait email{}

 class project{
 	use pdf; // we can cretae object tht why we "use fincton" use.
 	use excel;
 }

  $obj = new project();
  $obj->showpdf();
  $obj->showexcel();


?>