<form action="file_action.php" method="post" enctype="multipart/form-data">  
<input type="text" name="username">
<input type="text" name="userage">
<input type="file" name="userprofile">
<input type="submit" />
	
</form>