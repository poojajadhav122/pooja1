<?php
   //echo time();
   setcookie("product_name","jeans",time()+3600,"/");
   setcookie("product_price",10000,time()+3600,"/");
?>


<a href="delete_cookie.php">Delete</a>
<a href="show_cookie.php">Delete</a>