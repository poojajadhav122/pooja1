<?php
  echo "<pre>";
  print_r($_REQUEST);
  echo "</pre>";

  echo "<pre>";
  print_r($_FILES);
  echo "</pre>";

  //$dest ="upload/" .time().$_FILES['userprofile']['name'];
  // $dest ="upload/" .rand(1000,9999).$_FILES['userprofile']['name'];
  $dest ="upload/" .date('Y-m-d-H-i-s').$_FILES['userprofile']['name'];

  $tmppath = $_FILES['userprofile']['tmp_name'];

  $ans= move_uploaded_file($tmppath, $dest);
  var_dump($ans);



?>