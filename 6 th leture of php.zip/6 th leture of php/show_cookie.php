<?php
   print_r($_COOKIE);
?>