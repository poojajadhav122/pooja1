<?php
     session_start();
     echo session_id();
     $_SESSION['username'] = "pooja";

?>

<a href="show_session.php"> show</a>