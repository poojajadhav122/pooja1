$(document).ready(function(){
	//alert("Test");
	$(".btn-add").click(function(){
		records = $("#form-record").serialize();
		alert(records)
		$.post("../controller/add_record_action.php",records).success(function(response){
			console.log(response);
			//$(".msg_add").html(response);
		})
	})

})