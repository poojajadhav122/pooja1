<script>
windows.location.href="views/index.php";
</script>

<?php
header("location:views/index.php");
?>