<?php
	require_once 'db_helper.php';
	final class db_project extends db_helper
	{
		function show_record()
		{
			//echo "hello";
			//select id,fname,lname from dbrecords where 1;
			//select columns name from table name where condition

			return $this->select("*","student","1");
		}
		
		function add_record($fname,$lname)
		{
			return parent::insert("student","fname,lname","'$fname','$lname'");
		}

		function edit_record($fname,$lname)
		{
			//update users set us_password='$newpass' where us_email='$email
			return db_helper::update("student","fname='$fname'","lname='$lname'");
		}

	}

	$obj = new db_project();

?>