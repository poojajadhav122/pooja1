<!DOCTYPE html>
  <head>
    <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css"/>
    <link rel="stylesheet" type="text/css" href="../assets//css/style.css"/>
  </head>
  <body>
    <div class="container">
      <form method="post" action="../controllers/add_record_action.php">
        <div class="form-group">
          <label for="firstname">First Name</label>
          <input type="text" class="form-control" id="fname" placeholder="Your First Name">
        </div>
        <div class="form-group">
          <label for="lastname">Last Name</label>
          <input type="text" class="form-control" id="lname" placeholder="Your Last Name">
        </div>
        <button type="submit" class="btn btn-default">SAVE</button>
        <button type="submit" class="btn btn-default">CLOSE</button>
      </form>
    </div>
  </body>
</html>