
<?php
	require_once "../models/db_project.php";
?>
<link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../assets/css/style.css">

<div class="container">
	<h1>Information From Records Table</h1>
	<table class="table">
		<tr>
			<th>Id</th>
			<th>First Name</th>
			<th>Last Name</th>
			<th>Delete Record</th>
			<th>Edit Record</th>

		</tr>
		<?php
		    $result = $obj->show_record();
		    if(is_array($result)):
		    	foreach ($result as $val):
		?>
		<tr>
		   	<td><?php echo $val['id']; ?></td>
		    <td><?php echo $val['fname']; ?></td>
		    <td><?php echo $val['lname']; ?></td>
		    <td><a href='delete_record.php?xyz=$id'> Delete</a></td>
		    <?php
		      if (isset($_GET["id"])){
      
    $obj->id = $_GET["id"];
    $obj->delete();
    header("Location:index.php");
    exit;
 }

		    ?>
		    <td><a href='edit_record.php?xyz=$id'> Edit</a></td>
		</tr>
    	<?php
			endforeach;
			endif;
		?>	
 
	</table>
	<a href="index.php">ADD RECORD</a>
</div>