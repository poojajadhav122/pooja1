<?php 

	if(session_id()== ""){
		session_start();
		//echo session_id();
	}

	 require_once "function.php";
	 interface parameter{
	 	const HOSTNAME = "localhost";
	 	const  USER= "root";
	 	const  PASSWORD= "";
	 	const DATABASE = "stu_record";
	 }

	 interface db_general_function{

	function insert();
 	function update();
 	function delete();
 	function select();
	 
	 }


?>