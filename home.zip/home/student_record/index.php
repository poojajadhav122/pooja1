<?php
include('db.php');
?>
<table cellpadding="5" cellspacing="0" border="1">
	<tr>
		<th>id</th>
		<th>first_name</th>
		<th>last_name</th>
		<th>action</th>
	</tr>
    
    
	<tr>
		<td>3</td>
		<td>pillu</td>
		<td>jja</td>
		<td>
			<a href="#">edit</a>|
			<a href="#">delete</a>

		</td>
	</tr>
</table>