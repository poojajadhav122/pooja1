$(document).ready(function(){
	alert("test")
	$(".btn-update").click(function(){
		records = $("#update_form").serialize();
		//alert(records)
		$.post("../controllers/password-action.php",records).success(
			function(res){
				alert(res)
				//console.log(res);
				$(".msg_update").html(res);
			})
	})

	$(".btn-brand").click(function(){
		records = $("#brand_form").serialize();
		//console.log(records);
		$.post("../controllers/brand-action.php",records).success(
			function(res){
				alert(res)
				//console.log(res);
				$(".msg_brand").html(res);
			})
	})

$(".btn-category").click(function(){
		records = $("#category_form").serialize();
		//console.log(records);
		$.post("../controllers/category-action.php",records).success(
			function(res){
				alert(res)
				//console.log(res);
				$(".msg_category").html(res);
			})
	})

	


})