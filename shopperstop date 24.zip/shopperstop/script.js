$(".searchbox").mousemove(function(mouseobj){
		//console.log(mouseobj);
		//console.log(mouseobj.pageX);
		xpos = mouseobj.pageX;
		ypos = mouseobj.pageY;
		$(".tooltip").show();
		$(".tooltip").css("left",xpos+20)
		$(".tooltip").css("top",ypos+20)
	});
	$(".searchbox").mouseout(function(){
		$(".tooltip").hide();
	})

$(".tab_class_content").hide();
$(".tab_class_content:first").show();

$(".tab_class li").click(function(){
	position =$(this).index();
	//alert (position)
	$(".tab_class_content").hide();
	$(".tab_class_content").eq(position).fadeIn(500);
})


$(document).ready(function () {
	//alert(1)
var height = Math.round($(".product_box").height());/** this function  called as getor(because)**/
console.log(height)
var width = Math.round($(".product_box").width());
console.log(width)

$(".slide_box").height(height);/** this function is called as setor(because this store the value)**/
$(".slide_box").width(width);
$(".slide_box").css("top",-height);

$(".product_box").mouseenter(function(){
	// console.log("test")
	$(this).children(".slide_box").animate({
		"top":0
	},300);
})
$(".product_box").mouseleave(function(){
	// console.log("test1")
	$(this).children(".slide_box").animate({
		"top":-height
	},300);
})
//modal box
$(".greybox").hide();

$(".open_box").click(function(){
	$(".greybox").fadeIn(1000);
	$(".modalbox").animate({
		"top":"20%"
	},500)
})
$(".greybox").click(function(){
	$(".greybox").fadeOut(1000);
	$(".modalbox").animate({
		"top":"-410px"
	},500)
})

$(document).keypress(function(keyObject){
	//console.log(keyObject)
	//console.log(keyobject.keyCode)
	res_grey = $(".grey").css("display")
	//console.log(res_black);
	if(res_grey == "block" && keyObject.keyCode==27){
		$(".greybox").fadeOut(1000);
	$(".modalbox").animate({
		"top":"-410px"
	},500)
}
});
})
