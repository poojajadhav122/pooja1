<?php
include('server.php');
// fetch the record to be updated
if(isset($_GET['edit'])){
  $id = $_GET['edit'];
  $rec = mysqli_query($db,"select * from student where id=$id");
  $record = mysqli_fetch_array($rec);
  $fname  = $record['fname'];
  $lname  = $record['lname'];
  $id  = $record['id'];
}
?>
<!DOCTYPE html>
<html>
<head>
	
		<link rel="stylesheet" type="text/css" href="style.css">
	
</head>
<body>
	<table>
		<thead>
			<tr>
				<th>ID</th>
				<th>First Name</th>
				<th>Last Name</th>
				<th colspan="2">Action</th>
			</tr>
		</thead>
		<tbody>
			<?php
               while ($row = mysqli_fetch_array($results)){ ?>
               <tr>
				<td><?php echo $row['fname'];?></td>
				<td><?php echo $row['lname'];?></td>
				<td>
					<a href="index.php?edit=<?php echo $row['id'];?>">Edit</a>
				</td>
				<td>
					<a href="#">Delete</a>
				</td>
			</tr>
			<?php }?>
			
		</tbody>
	</table>

	<form method="post" action="server.php">
		<input type="hidden" name="id" value="<?php echo $id;?>">
		<div class="input">
			<label> First Name</label>
			<input type="text" name="fname" value="<?php echo $fname;?>">
		</div>
		<div class="input">
			<label>Last Name</label>
			<input type="text" name="lname" value="<?php echo $lname;?>">
		</div>
		<div class="input">
			<?php if ($edit_state == false);?> 
			<button type="submit" name="save" class="btn">Save</button>
		
           <button type="submit" name="update" class="btn">Update</button>
          		
		</div>
	</form>

</body>
</html>