<?php
    //initalize varible
    $fname ="";
	$lname  ="";
	$id = 0;
	$edit_state = false;
// connect to database
$db = mysqli_connect('localhost','root','','record');
// if clicked save button
if (isset($_POST['save'])) {
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];

	$query = "insert into student(fname ,lname ) values('$fname','$lname')";
	mysqli_query($db,$query);
	header('location:index.php');
}


//retrive records
$results = mysqli_query($db,"select * from student");


?>