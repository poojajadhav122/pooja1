create table student(

	id int auto_increment primary key,
	fname varchar(100)
    lname varchar(100)

);

