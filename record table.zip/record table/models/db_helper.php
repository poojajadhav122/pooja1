<?php  

 require_once "db_connect.php";

 


 function insert($table,$columns,$values){

   if (isset($_POST['save'])) {
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];

	$query = "insert into student(fname ,lname ) values('$fname','$lname')";
	mysqli_query($db,$query);
	header('location:index.php');
}

 	}
 	

?>