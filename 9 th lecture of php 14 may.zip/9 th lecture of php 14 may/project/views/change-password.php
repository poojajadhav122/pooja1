<?php
session_start();
 print_r($_SESSION);
 if(!isset($_SESSION['project_name'])){
 	header("location:index.php");
 }

require_once 'header.php';
?>
 <h2>Change password</h2>
 <div class="container">
 <div class="col-sm-4">
					<div class="signup-form"><!--sign up form-->
						<h2>UPDATE PASSWORD</h2>
	<form id="register_form">
	<input type="text" name="username" placeholder="ENTER NAME" />
	<input type="password" name="usermobile" placeholder="ENTER MOBILE NUMBER" />
	<input type="text" name="useremail" placeholder="ENTER EMAILID" />
	<input type="password" name="userpassword" placeholder="ENTER PASSWORD" />
	<input type="password" name="usercpassword" placeholder="ENTER OMFIRM PASSWORD" />
	<button type="button" class="btn btn-default btn-register">Register</button>
	</form>
	<div class="msg_register"></div>
					</div><!--/sign up form-->
				</div>
				</div>
<?php
require_once 'footer.php';
?>