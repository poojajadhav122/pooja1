<link rel="stylesheet" type="text/css" href="bootstrap.min.css">

<div class="container" >
	<form method="post" action="add_record_action.php">
		<label>ENTER NAME</label>
		<input type="text" name="username" placeholder="Enter Name" class="form-control">
		
		<label>ENTER SALARY</label>
		<input type="text" name="usersalary" placeholder="Enter salary" class="form-control">

		<input type="submit" class="btn">
		
	</form>
</div>
 