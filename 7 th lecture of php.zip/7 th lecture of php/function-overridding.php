<?php
   
  
  abstract class tv {
  	 function showchannel(){
  	 	echo "DD TV";
  	 }
  	}
 

   class sonytv extends tv{
    function showchannel(){ //if 2 function called with same name that timewe doing this way
    	echo "SONY TV";
    	//$this->showchannel();
    	tv::showchannel();
    	parent::showchannel();
    }
    }

    $remote = new sonytv();
    $remote->showchannel();
?>