<?php

   class tv{
   	public $color="rgb";
   	public $sound = "dolby";
   	protected $channel1= "zee";
   	private $channel2 ="star";

   	public function show_channel(){
   		echo "<hr/>";
   		echo "<pre>";
   		print_r($this);
   		echo "</pre>";

   		echo $this->color;
   		echo $this->sound;
   		echo $this->channel1;
   		echo $this->channel2;
   		
   	}
   }
   $remote = new tv;
   echo "<pre>";
   print_r($remote);
   echo "</pre>";
   $remote->show_channel();




?>