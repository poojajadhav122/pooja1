<?php
     class tv{ // this part is called as a storage class//
     	var $color = "rgb";
     	var $sound = "Dolby";
     }
       

       //$remote = tv();
         //$remote = tv;
        // $remote = new tv();

      $remote = new tv; // this part is called as the instance creation or object// 
      echo "<pre>";
      print_r($remote);
      echo "</pre>";

      //echo $remote['color']; this part i called as array but we cannot declare in oops.

      echo $remote->color;
      echo $remote->sound;

      foreach ($remote as $ans ) {
      	echo $ans;
      }
?>
