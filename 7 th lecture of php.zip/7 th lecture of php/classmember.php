<?php
     class tv{ // this part is called as a storage class//
     	//private,protected,public(var)
     	//members this is called generic
     	//properties  
     	var $color = "rgb";
     	var $sound = "Dolby";
     	var $power = ["on","off"];
     
       
      public function channel(){ //this is called as method
      	echo "zee tv";
      }
      public function newchannel1(){
      	echo 1000;
      	return "star tv"; // this return stop the exctuion futher line
      	echo 1000;
      }

      const PI = 3.142;
  }
     
      $remote = new tv; // this part is called as the instance creation or object// 
      echo "<pre>";
      print_r($remote);
      echo "</pre>";

       echo $remote->color;
      echo $remote->sound;
      echo $remote->power[0];
      echo $remote->power[1];

      $remote->channel();

      echo $remote->newchannel1();

      echo tv:: PI;//this :: is xalled as scope to access theconstant 



?>