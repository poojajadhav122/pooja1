<?php
   $dob = "4/10/1995";
  // echo $dob;
   //4 10 1992
   $result = explode("/", $dob);
   print_r($result);
   echo "<hr />";
   $arr = array(4,10,1995);
   print_r($arr);
   echo implode("-",$arr);

   echo "<hr/>";

   $dob = "4/10/1995";
   //echo $dob;
   // 4 10 1995
   list($date,$month,$year) = explode("/", $dob);
   echo $year;

?>