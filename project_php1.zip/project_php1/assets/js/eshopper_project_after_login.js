$(document).ready(function(){
	alert("test")
	$(".btn-update").click(function(){
		records = $("#update_form").serialize();
		alert(records)
		$.post("../controllers/password-action.php",records).success(
			function(res){
				alert(res)
				//console.log(res);
				$(".msg_update").html(res);
			})
	})
})