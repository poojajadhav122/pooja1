<?php
//print_r($_POST);
$proid = $_POST['x'];
//echo $proid;
//4 in op
$cartdata = $_COOKIE['cookie_product_id'];
//echo $cartdata;
// 2,1,3,2 in op
$arr = explode(",",$cartdata);
//print_r($arr);
//arr(1,2,3,1) in op
foreach ($arr as $key => $val) {
	//echo $val;
	  //echo $key;
	unset($arr[$key]);
}

//print_r($arr);
$newproduct = implode(",", $arr);
//echo $newpro;
setcookie("cookie_product_id",$newproduct,time() + 36000,"/");

$ans = explode(",", $newproduct);
//print_r($ans);
$result = array_unique($ans);
//print_r($result);
echo count($result);


?>