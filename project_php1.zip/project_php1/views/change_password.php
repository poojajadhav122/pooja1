<?php  
	
	session_start();
	if(!isset($_SESSION['project_usname'])){
		header("location:index.php");
	}
	require_once "header.php";
?>

		
		<div class="container">
			<div class="col-md-4 text-center">
				<div class="signup-form"><!--sign up form-->
					<h2>Update password</h2>
					<form id="update_form">
					<!-- <input type="text" name="username" placeholder="enter name" /> -->
					<input type="password" name="cpass" placeholder="enter current password"/>
					<!-- <input type="text" name="usernumber" placeholder="enter mobile number" /> -->
					<input type="password" name="npass" placeholder="enter new password" />
					<input type="password" name="cnpass" placeholder="enter confirm new password" />


					<button type="button" class="btn btn-default btn-update">Update</button>
					</form>
					<div class="msg_update"></div>
				</div>
			</div>
		</div>

<?php 

	require_once "footer.php";
?>