<?php
     $product_arr = array(
     0=>array("product1",200,"a.jpg"),
     1=>array("product2",300,"b.jpg"),
     2=>array("product3",400,"c.jpg"),
     3=>array("product4",500,"d.jpg"),
     );
     //refer file product.php
?>

