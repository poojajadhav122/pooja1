<?php
  include("dummpy.php");
  include "dummpy.php";
  include_once "dummpy.php";

  require ("dummpy.php");
  require "dummpy.php";
  require_once "dummpy.php";

  /* echo 1000;
   include "dummpy1.php";
   echo 1000;*/

    echo 1000;
   require "dummpy1.php";
   echo 1000;
  
?>