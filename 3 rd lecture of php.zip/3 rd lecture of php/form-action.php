<?php
   //echo "<pre>";
   //print_r($_GET);
   
   //print_r($_REQUEST);
  // echo "</pre>";


//echo "<pre>";
 //print_r($_POST);
  //echo "</pre>";

  echo "<pre>";
 print_r($_REQUEST);
  echo "</pre>";

  
  //refer file form
?>