<?php
     // 7 global arrays
print_r($_GET); #to get information about the link
echo "<br>";
print_r($_REQUEST);

foreach ($_REQUEST as $val ) {
	echo $val." ";
}
 //  refre file ex23.php

?>