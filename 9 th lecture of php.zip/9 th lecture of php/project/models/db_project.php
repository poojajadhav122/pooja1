<?php
   require_once 'db_helper.php';
   final class db_project extends db_helper{

   }
   $obj = new db_project();

?>