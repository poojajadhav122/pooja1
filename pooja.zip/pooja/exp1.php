<b> pooja</b> 
<style >
	b{background:pink;}
</style>
<script >
	alert(1)
</script>


<?php

echo 100
?>