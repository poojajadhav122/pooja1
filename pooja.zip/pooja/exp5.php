<?php

 echo strlen('Hello Pooja');
echo "<br>";
echo strlen("hello pooja");
?>

