<?php
     const DATABASE ="Eshopper";
     //const DATABASE = "new Database";
     echo DATABASE;
     //echo database; 


?>