<?php
  define('DATABASE',"Eshopper",true)
  //define('DATABASE',"New DB");
  echo DATABASE;
  echo database;


?>