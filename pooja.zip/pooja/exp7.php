<?php

    echo strtolower("Hello World");
    echo "<br>";
    echo strtoupper("Hello World");
    echo "<br>";
    echo ucwords("Hello World");
    
    echo strtolawer("Hello World");

    echo strtolower("Hello World");

?>