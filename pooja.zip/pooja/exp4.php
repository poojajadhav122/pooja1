<?php
  // comment example  single line comment
  # comment example
/* 
multiple line comment
*/

#type of error: notice error


$x1=100;
echo $X1;

echo $x1;
?>