<?php
   
    for($i=1;$i<=10;$i++) //here we  did for loop to print nos from 1 to 5 and again we square them 

    {                // to print just nos we write only $i
    	echo $i*$i; // that why we here written $i*$i to get square
    	echo " ";
    }


    $x=1; //initlaize
    while($x<=5){  // in while loop condition come in barcket and initalize and increment come outside the barcket

    	echo $x; // increment
    	echo " ";
    	$x++;

    }
?>    