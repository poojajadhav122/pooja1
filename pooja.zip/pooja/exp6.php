<?php
 
   $x = 10;
   $y = $x*$x;

    echo "square of $x is $y";//indouble quote it takes the variable and display the op
    echo "<br>";              // this is the html tage of break the line so we have to convert in php that why we wite this way
    echo 'square of $x is $y';// in single qoute dosenot take the variable
?>