<a href="ex23.php?name=Kurta&amount=1000&color=blue">Mens</a> <br>

<a href="ex23.php?name=shrit&amount=2000&color=black">WoMens</a> <br>

<a href="ex23.php?name=Shoe&amount=3000&color=pink">Kids</a> 