<?php
 $x1=100;
 $x2=200;
   echo $x1,$x2; /* in echo we can get any type of output*/
   //print $x1,$x2;/*in print we not get output without giving the expression*/
   ?>