create table brands1(
     br_id int auto_increment primary key,
     br_name varchar(100)
);



create table categories(
     ca_id int auto_increment primary key,
     ca_name varchar(100)
);

create table product(
	ca_id int auto_increment primary key,
     ca_name varchar(100)
);