<?php
   require_once 'db_helper.php';
   final class db_project extends db_helper{
       function show_brands(){
       	//echo "HELLO";
        //select br_id,br_name from brands where1
       	return $this->select(
       		"br_id,br_name","brands1","1"
       	);
       }
       function show_categories(){
       	//echo "HELLO";
        //select br_id,br_name from brands where1
       	return $this->select(
       		"ca_id,ca_name","categories","1"
       	);
       }
       
   }

   $obj = new db_project();

?>